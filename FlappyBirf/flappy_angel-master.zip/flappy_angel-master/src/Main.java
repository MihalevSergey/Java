import processing.core.PApplet;

public class Main {

    private final static String[] OPTIONS = new String[] {"--present", "Sketch"};

    public static void main(String ... args){
        PApplet.main(OPTIONS);
    }

}
